import { NgModule } from '@angular/core';
import { SidebarComponent } from './sidebar.component';
import { Routes, RouterModule } from '@angular/router';
const routes: Routes = [
    {
        path: '',
        component: SidebarComponent
    }
];
@NgModule({
  declarations: [
    SidebarComponent,
  ],
  imports: [
    SidebarComponent,
    RouterModule.forChild(routes)
  ],
  exports : [
    SidebarComponent,
    RouterModule
  ],
  bootstrap: [SidebarComponent]
})
export class SidebarModule { }
