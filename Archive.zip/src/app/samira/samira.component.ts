import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HotelService } from '../hotel.service';
import { AuthenticationService} from '../authentication.service';
@Component({
  selector: 'app-samira',
  templateUrl: './samira.component.html',
  styleUrls: ['./samira.component.css']
})
export class SamiraComponent implements OnInit {
  hotels: any;
  constructor(private router: Router, private hotelService: HotelService, private auth: AuthenticationService) { }
  ngOnInit() {
    this.getVenderHotels();
  }

  getVenderHotels() {
    this.hotelService.get().subscribe(res => {
      this.hotels = res;
    },
    err => {
      console.error(err);
    });
  }

}
