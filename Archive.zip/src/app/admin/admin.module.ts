import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AdminComponent } from './admin.component';
import { AdminRoutingModule } from './admin-routing.module';

@NgModule({
  declarations: [
    AdminComponent
    ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AdminRoutingModule,
  ],
  bootstrap: [AdminComponent]
})
export class AdminModule { }
