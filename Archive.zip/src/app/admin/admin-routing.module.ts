import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule , Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from '../home/home.component';
import { LoginComponent } from '../login/login.component';
import { RegisterComponent } from '../register/register.component';
import { ProfileComponent } from '../profile/profile.component';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { AuthenticationService } from '../authentication.service';
import { AuthGuardService } from '../auth-guard.service';
import { HotelComponent } from '../hotel/hotel.component';
import { RoomComponent } from '../room/room.component';
import { HotelAddComponent } from '../hotel/hotel-add/hotel-add.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTableModule } from '@angular/material/table';
import { FileSelectDirective } from 'ng2-file-upload';
import { MatSortModule } from '@angular/material/sort';


const routes: Routes = [
    {path: 'login', component: LoginComponent},
    {path: 'register', component: RegisterComponent},
    {path: 'hotel', component: HotelComponent , canActivate: [AuthGuardService]},
    {path: 'room', component: RoomComponent , canActivate: [AuthGuardService]},
    {path: 'hotel/add', component: HotelAddComponent , canActivate: [AuthGuardService]},
    {path: 'hotel/edit', component: HotelAddComponent , canActivate: [AuthGuardService]},
    {path: 'profile', component: ProfileComponent , canActivate: [AuthGuardService]},
];
@NgModule({
  declarations: [
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    ProfileComponent,
    SidebarComponent,
    HotelComponent,
    HotelAddComponent,
    FileSelectDirective,
    RoomComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatSortModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  providers: [AuthenticationService , AuthGuardService],
})
export class AdminRoutingModule { }
