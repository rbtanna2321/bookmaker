import { Component, OnInit , ViewChild } from '@angular/core';
import { HotelService } from '../hotel.service';
import { Router } from '@angular/router';
import { AuthenticationService} from '../authentication.service';

@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css']
})
export class HotelComponent implements OnInit {
  constructor(private router: Router, private hotelService: HotelService, private auth: AuthenticationService) { }
  hotels: any;
  editHotel: any;
  id = {id: ''};
  ngOnInit() {
    this.getVenderHotels();
  }

  getVenderHotels() {
  this.hotelService.get().subscribe(res => {
    this.hotels = res;
    console.log(this.hotels);
  },
  err => {
    console.error(err);
  });
}
onUpdate(){
  this.hotelService.update(this.editHotel).subscribe(res => {
    console.log(res)
  },error =>{
    console.log(error)
  })
}

deleteHotel(){
  this.hotelService.delete(this.id).subscribe(res => {
    console.log(res)
  },error =>{
    console.log(error)
  });

}

}

