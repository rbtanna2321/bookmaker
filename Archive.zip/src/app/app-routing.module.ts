import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule , Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AuthenticationService } from './authentication.service';
import { AuthGuardService } from './auth-guard.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTableModule } from '@angular/material/table';
import { FileSelectDirective } from 'ng2-file-upload';
import { MatSortModule } from '@angular/material/sort';


const routes: Routes = [
  {path: 'samira', loadChildren: './samira/samira.component'},
  {path: 'admin', loadChildren: './admin/admin.component'}
];
@NgModule({
  declarations: [
    FileSelectDirective,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatSortModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  providers: [AuthenticationService , AuthGuardService],
})
export class AppRoutingModule { }
