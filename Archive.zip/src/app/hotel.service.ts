import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class HotelService {
  baseUrl = 'http://localhost:3000';
  constructor(private http: HttpClient) { }


  post(data) {
    return this.http.post(this.baseUrl + '/hotels/hotel/add', data);
  }
  update(data) {
    return this.http.post(this.baseUrl + '/hotels/hotel/update', data);
  }
  delete(id) {
    return this.http.post(this.baseUrl + '/hotels/hotel/delete', id);
  }
  get() {
    return this.http.get(this.baseUrl + '/hotels/hotel');
  }
}
