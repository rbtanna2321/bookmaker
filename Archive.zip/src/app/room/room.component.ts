import { Component, OnInit , ViewChild } from '@angular/core';
import { RoomService } from '../room.service';
import { Router } from '@angular/router';
import { AuthenticationService} from '../authentication.service';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {
  constructor(private router: Router, private roomService: RoomService, private auth: AuthenticationService) { }
  rooms: any;
  ngOnInit() {
    this.getVenderrooms();
  }

  getVenderrooms() {
  this.roomService.get().subscribe(res => {
    this.rooms = res;
    console.log(this.rooms);
  },
  err => {
    console.error(err);
  });
}
}

