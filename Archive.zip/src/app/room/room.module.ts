import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoomRoutingModule } from './room-routing.module';
import { AddRoomComponent } from './add-room/add-room.component';
import { RoomComponent } from './room.component';

@NgModule({
  declarations: [AddRoomComponent, RoomComponent],
  imports: [
    CommonModule,
    RoomRoutingModule
  ]
})
export class RoomModule { }
